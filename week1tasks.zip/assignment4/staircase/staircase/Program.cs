﻿using System.Runtime.InteropServices;

namespace staircase
{
    internal class Program
    {
        static void print(int n)
        {
            for (short i = 1; i <= n; ++i)
            {
                for (int j = 1; j <= n; ++j)
                {
                    if (j <= n - i)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("#");
                    }
                }
                Console.WriteLine();
            }
        }
        
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            int number = 4;
            print(4);

        }
    }
}