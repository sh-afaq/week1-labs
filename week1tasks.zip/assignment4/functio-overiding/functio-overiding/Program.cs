﻿namespace functio_overiding
{
    internal class Program
    {
        internal class sports
        {
            public String getName()
            {
                return "Generic Sports";
            }
            public virtual void getNumberOfTeamMembers()
            {
                Console.WriteLine("Each team has n players in " + getName());
            }
        }
        internal class soccer: sports
        {

            public override void getNumberOfTeamMembers()
            {
                Console.WriteLine("Each team has 11 players in " + getName());
            }


        }
            

        static void Main(string[] args)
        {
            sports sports = new sports();
            soccer soccer = new soccer();
            string answer=sports.getName();
            Console.WriteLine(answer);
            
            
            sports.getNumberOfTeamMembers();
            Console.WriteLine("soccer class");
            soccer.getNumberOfTeamMembers();

        }
    }
}