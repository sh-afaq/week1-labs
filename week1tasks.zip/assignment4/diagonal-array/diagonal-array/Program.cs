﻿namespace diagonal_array
{
    internal class Program
    {
        static int diagonal(int[,] array)
        {
            int sum1=0,sum2=0;int diff = 0;
            for(int i=0;i<1;i++)
            {
                for(int j=0;j<1;j++)
                {
                    sum1 = array[i, j] + array[i + 1, j + 1] + array[i + 2, j + 2];
                    sum2 = array[i, j + 2] + array[i + 1, j + 1] + array[i + 2, j];
                    
                }

            }
            diff = sum2 - sum1;
            return diff;





        }
        
        static void Main(string[] args)
        {
            int[,] s = new int[3, 3] { { 11, 2, 4 }, { 4, 5, 6 }, { 10, 8,-12 } };

            int diff = diagonal(s);
            Console.WriteLine(diff);
            

        }
    }
}