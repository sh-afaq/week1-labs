﻿using System;

namespace strongpassword
{
    internal class Program
    {
        static void mypass(string s,int n)
        {
            bool check1 = false;
            bool check2 = false;
            bool check3 = false;
            bool check4 = false;
            char[] one =s.ToCharArray();
            //string checker="!@#$%^&*()-+";
           
            //string d = "!@#$%^&*()-+";
            for (int i=0;i<s.Length-1;i++)
            {
                if (s[i] >= 'A' && s[i] <= 'Z')
                {
                    check1 = true;
                }
                
                else if (s[i] >= 'a' && s[i] <= 'z')
                {
                    check2 = true;
                }
                else if (s[i]>='0' && s[i]<='9')
                {
                    check3 = true;
                }
                else if (s[i]== '!' || s[i]== '@'|| s[i]== '#' ||s[i]== '$'||s[i]== '%'||s[i]== '^'||
                s[i]== '&'||s[i]== '*' ||s[i]== '('||s[i]== ')'||s[i]== '-'||s[i]=='+') 
                {
                    
                    check4 = true;
                }
            }//loop end
            
            if(check1 && check2 && check3 && check4 )
            {
                Console.WriteLine("strong password");
            }
            else if(!(check1))
            {
                Console.WriteLine("enter uppercase");
            }
            else if(!(check2))
            {
                Console.WriteLine("enter lowercase");
            }
            else if(!(check3))
            {
                Console.WriteLine("enter digit");
            }
            else if(!(check4))
            {
                Console.WriteLine("enter special character");
            }
            else
            {
                Console.WriteLine("not working");
                

            }
            if(n<6)
            {
                int required_number = 6 - n;
                Console.WriteLine("you need to enter");
                Console.WriteLine(required_number);
                Console.WriteLine("more letters");
            }

        }
        
        static void Main(string[] args)
        {
            string password = "abcD!6";
            int length = 6;
            mypass(password, length);
        }


        }
}