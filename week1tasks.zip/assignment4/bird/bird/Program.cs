﻿namespace bird
{
    internal class Program
    {
        static int my_func(int[] arr)
        {
            int number1 = 0,number2=0,count1=0,count2=0;
            for(int i=0;i<arr.Length-1;i++)
            {
                if (arr[i + 1] == arr[i])
                {
                    if (number1 < arr[i] && number1==0)
                    {
                        number1 = arr[i];
                        count1++;

                    }
                    else if (arr[i]>number1)
                    {
                        number2 = arr[i];
                        count2++;
                    }
                }

            }
            if(count1>count2)
            {
                return number1;
            }
            else
            {
                return number2;

            }
            
        }
        static void Main(string[] args)
        {
            int  small_number;
            int[] number = { 2, 2,3, 3,3 };
            small_number = my_func(number);
            Console.WriteLine(small_number);
        }
    }
}