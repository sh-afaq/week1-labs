﻿namespace garde
{
    internal class Program
    {
        static int [] my_func(int[] arr)
        {
            int result;
            for(int i=0;i<arr.Length-1;i++)
            {
                if (arr[i]<40)
                {
                    result = 40 - arr[i];
                    if(result<3)
                    {
                        arr[i] = arr[i] + result;
                    }
                    else
                    {
                        arr[i] = arr[i];
                    }
                }
                else if (arr[i]%5==4 || arr[i]%5==9)
                {
                    arr[i] = arr[i] + 1;
                }
                else if (arr[i]%5==3)
                {
                    arr[i] = arr[i] + 2;
                }
            }
            return arr;
        }
        static void Main(string[] args)
        {
            int[] grade = {4,73,67,38,33};
            int[] result;
            result = my_func(grade);
            foreach (var item in result)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}