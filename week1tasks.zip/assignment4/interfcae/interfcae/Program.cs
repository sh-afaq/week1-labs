﻿namespace interfcae
{
    internal class Program
    {
        internal interface AdvancedArithmetic
        {
            int divisor_sum(int n);
        }
        internal class MyCalculator
        {
            public int divisor_sum(int n)
            {
                int div = n , sum = 0;
                while (div > 0)
                {
                    if ((n % div) == 0)
                    {
                        sum = sum + div;
                    }
                    div--;
                }
                return sum;
            }
        }
        static void Main(string[] args)
        {
            MyCalculator calculator = new MyCalculator();
            int sum=calculator.divisor_sum(6);
            Console.WriteLine("sum of divisors is: " +sum);
        }
    }
}