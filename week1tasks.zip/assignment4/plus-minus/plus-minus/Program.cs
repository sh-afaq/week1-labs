﻿namespace plus_minus
{
    internal class Program
    {
        static void ratio(int[] array)
        {
            int length = array.Length; float positive=0f , negative=0f, zero=0f;
            
            for(int i=0;i<array.Length;i++)
            {
                if (array[i]>0)
                {
                    positive++;
                }
                else if (array[i]<0)
                {
                    negative=negative+1;
                }
                else
                {
                    zero=zero+1;
                }
            }
            Console.WriteLine("POSITIVE RATIO IS:");
            Console.Write("{0:F6} ", positive / length);
            Console.WriteLine();
            Console.WriteLine("NEGATIVE RATIO IS:");
            Console.Write("{0:F6} ", negative / length);
            Console.WriteLine();
            Console.WriteLine("ZERO RATIO IS:");
            Console.Write("{0:F6} ", zero / length);
            Console.WriteLine();

        }
        static void Main(string[] args)
        {
            int[] s = { 1, 1, 0, -1, -1 };
            ratio(s);
        }
    }
}