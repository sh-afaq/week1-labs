﻿namespace ARRAY_SUM
{
    internal class Program
    {
        static int sum_array(int[] array)
        {
            int sum = 0;
            for(int i=0;i<array.Length;i++)
            {
                sum = sum + array[i];
            }
            return sum;
        }
        static void Main(string[] args)
        {
            int[] s = { 12, 34, 21, 45 };
            int result;
            result = sum_array(s);
            Console.WriteLine("sum of array is: " +result);
        }
    }
}