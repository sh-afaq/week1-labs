﻿using System.Dynamic;

namespace inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bird obj = new bird();
            obj.walk();
            obj.fly();
            obj.sing();
        }
    }
}