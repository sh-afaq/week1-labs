﻿

namespace inheritance
{
    internal class animal
    {
        public  void walk()
        {
            Console.WriteLine("i am walking");
        }
    }
    internal class bird: animal
    {
        public  void fly()
        {
            Console.WriteLine("i am flying");
        }
         public  void sing()
        {
            Console.WriteLine("i am singing");
        }
    }
}
