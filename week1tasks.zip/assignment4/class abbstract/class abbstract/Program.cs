﻿namespace class_abbstract
{
    internal class Program
    {
        internal abstract class Book
        {
            public string title=" ";
            public abstract void setTitle(String s);
            String getTitle()
            {
                return title;
            }
        }
        internal class Novel : Book
        {
            public override void setTitle(String s)
            {
                title = s;
                Console.WriteLine("the title is: " + title);
            }
        }
        static void Main(string[] args)
        {
                Novel my_novel = new Novel();
                my_novel.setTitle("a tale of two cities");
        }
    }
}