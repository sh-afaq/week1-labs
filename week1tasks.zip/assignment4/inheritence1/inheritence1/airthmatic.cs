﻿

namespace inheritence1
{
    internal class airthmatic
    {
        public int my_func(int a,int b)
        {
            return a + b;
        }
    }
    internal class adder : airthmatic
    {
        public void name()
        {
            string name=typeof(adder).BaseType.Name;
            Console.WriteLine("my super class is:"+ name);
        }
        
    }
}
