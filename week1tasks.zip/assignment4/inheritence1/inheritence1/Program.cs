﻿namespace inheritence1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            adder obj = new adder();
            int result,result1,result2;
            result=obj.my_func(20,22);
            result1 = obj.my_func(6,7);
            result2 = obj.my_func(10, 10);

            obj.name();
            Console.WriteLine(result);
            Console.WriteLine(result1);
            Console.WriteLine(result2);

        }
    }
}