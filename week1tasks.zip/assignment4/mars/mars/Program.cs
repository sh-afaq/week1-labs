﻿namespace mars
{
    internal class Program
    {
        static int count = 0;
        static int mars_check(string s)
        {
            for(int i=0;i<s.Length;i++)
            {
                if (!(s[i]=='s' || s[i]=='o'))
                {
                     count++;

                }
            }
            return count;
        }
        static void Main(string[] args)
        {
            string my_string = "sostorso";
            int result;
            result = mars_check(my_string);
            Console.WriteLine("NUMBER OF CHANGED CHARACTERS ARE : "+result);
        } 
    }
}