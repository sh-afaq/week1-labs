﻿using System.ComponentModel.DataAnnotations;

namespace candle
{
    internal class Program
    {
        static int my_func(int[] candle)
        {
            int max=0,count=0;
            for(int i=0;i<candle.Length-1;i++)
            {
                if (candle[i+1] > candle[i])
                {
                    if (max < candle[i+1])
                    {
                        max = candle[i + 1];
                        count++;

                    }
                    else if (max == candle[i+1])
                    {
                        count++;
                    }
                    
                }
                else
                {
                    max = candle[i];
                    count++;
                }
            }
            return count;
        }
        static void Main(string[] args)
        {
            int result;
            int[] arr = { 4, 4, 1, 3,4 };
            result = my_func(arr);
            Console.WriteLine(result);
        }
    }
}