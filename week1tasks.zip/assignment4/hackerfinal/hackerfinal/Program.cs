﻿namespace hacker
{
    internal class Program
    {
        static void check(char[] s)
        {
            char[] arr = new char[18]; int j = 0;
            for (int i = 0; i < s.Length-1; i++)
            {
                if (s[i] == 'h' || s[i] == 'a' || s[i] == 'c' || s[i] == 'k' || s[i] == 'e' || s[i] == 'r' || s[i] == 'a' || s[i] == 'n' || s[i] == 'k')
                {
                    //Console.WriteLine(s[i]);


                    arr[j] = s[i];
                    j++;

                }

            }
            check2(arr);
            //Console.WriteLine(arr);

        }

        static void check2(char[] array)
        {

            int number10 = 0, number1 = 0, number3 = 0, number4 = 0,
                number5 = 0, number6 = 0, number7 = 0, number8 = 0, number9 = 0;int number2=0;
            
            char name;
            for (int i = 0; i < array.Length - 1; i++)
            {

                if (array[i] == 'h')
                {
                    name = array[i];
                    number1 = Array.IndexOf(array, name);
                    Console.WriteLine("number1: " + number1);

                }
                /*else if (array[i] == 'a')
                {
                    name = array[i];
                    number2 = Array.IndexOf(array, name);
                    Console.WriteLine("number2: "+number2);

                }*/
                else if (array[i] == 'c')
                {
                    name = array[i];
                    number3 = Array.IndexOf(array, name);
                    Console.WriteLine("number3: " + number3);

                }

                /*else if (array[i] == 'k')
                 {
                     name = array[i];
                     number4 = Array.IndexOf(array, name);
                     Console.WriteLine("number4: "+number4);

                }*/
                else if (array[i] == 'e')
                {
                    name = array[i];
                    number5 = Array.LastIndexOf(array, name);
                    Console.WriteLine("number5: " + number5);

                }

                else if (array[i] == 'r' && i <= 2)
                {

                    continue;


                }
                else if ((array[i] == 'r') && (array[i + 1] == 'r'))
                {

                    name = array[i];
                    number6 = Array.LastIndexOf(array, name) - 1;
                    Console.WriteLine("number6: " + number6);


                }
                else if (array[i] == 'r')
                {
                    name = array[i];
                    number7 = Array.LastIndexOf(array, name);
                    Console.WriteLine("number7: " + number7);

                }


                else if ((array[i] == 'a'))
                {
                    name = array[i];
                    if(i==4)
                    {
                        number2 = i;
                    }
                    
                    number8 = Array.LastIndexOf(array, name);
                    Console.WriteLine("number8 :" + number8);
                    Console.WriteLine("number2 :" + number2);

                }
                else if (array[i] == 'n')
                {
                    name = array[i];
                    number9 = Array.IndexOf(array, name);
                    Console.WriteLine("number9 :" + number9);

                }
                else if ((array[i] == 'k'))
                {
                    name = array[i];
                    if(i==7)
                    {
                        number4 = i;
                    }
                   
                    number10 = Array.LastIndexOf(array, name);
                    Console.WriteLine("number10 :" + number10);
                    Console.WriteLine("number4 :" + number4);

                }

            }


            if (number1 < number2 && number2 < number3 && number3 < number4 &&
                number4 < number5 && number5 < number6 && number6 < number7 && number7 < number8 &&
                number8 < number9 && number9 < number10)
            {
                Console.WriteLine("yes");
            }
            else
            {
                Console.WriteLine("no");
            }
        }
        static void Main(string[] args)
        {
            char[] main = { 'h', 'e', 'r', 'e', 'i', 'a', 'm', 's', 't', 'a', 'c', 'k', 'e', 'r', 'r', 'a', 'n', 'k' };
            char[] array2 = { 'h', 'a', 'c', 'k', 'e', 'r', 'w', 'o', 'r', 'l', 'd' };
            //check(main);
            check(array2);

        }
    }
}


